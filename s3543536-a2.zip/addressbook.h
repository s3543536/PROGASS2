#ifndef ADDRESSBOOK_H
#define ADDRESSBOOK_H

#include "commands.h"
#include <stdio.h>
void menu();
#endif
